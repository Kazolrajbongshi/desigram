@extend('login_registration.master')
<?php $__env->startSection('content'); ?>

    <div class="container">
      <div class="row">
          <div class="wizard">
              <div class="wizard-inner">
                  <div class="connecting-line"></div>
                  <ul class="nav nav-tabs" role="tablist">

                      <li role="presentation">
                          <a class="active" href="<?php echo e(URL::to('user-registration')); ?>" title="Step 1">
                              <span class="round-tab">
                                  <p>#1</p>
                              </span>
                          </a>
                      </li>

                      <li role="presentation" class="disabled">
                          <a href="<?php echo e(URL::to('instagram-info')); ?>" title="Step 2">
                              <span class="round-tab">
                                  <p>#2</p>
                              </span>
                          </a>
                      </li>

                      <li role="presentation" class="disabled">
                          <a href="<?php echo e(URL::to('registration-success')); ?>" title="Complete">
                              <span class="round-tab">
                                  <p>#3</p>
                              </span>
                          </a>
                      </li>
                  </ul>
              </div>

              <div class="sign_up_form">
                <div class="form_title">
                  <h3>sign up</h3>
                </div>
                <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-group<?php echo e($errors->has('company_name') ? ' has-error' : ''); ?>">
                      <label for="companyname">Company Name</label>
                      <input type="text" class="form-control" name="company_name" id="company_name" placeholder="Company Name" value="<?php echo e(old('company_name')); ?>" required="">
                      <?php if($errors->has('company_name')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('company_name')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                      <label for="contactname">Contact Name</label>
                      <input type="text" class="form-control" name="name" id="name" placeholder="Contact Name" value="<?php echo e(old('name')); ?>" required="">
                      <?php if($errors->has('name')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('name')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
                      <label for="mobile">Mobile No</label>
                      <input type="number" class="form-control" name="mobile" id="mobile" placeholder="Mobile No" value="<?php echo e(old('mobile')); ?>" required="">
                      <?php if($errors->has('mobile')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('mobile')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                      <label for="email">Email address</label>
                      <input type="email" class="form-control" name="email" id="email" placeholder="example@email.com" value="<?php echo e(old('email')); ?>" required="">
                      <?php if($errors->has('email')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('email')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                      <label for="password">Enter Password</label>
                      <input type="password" class="form-control" name="password" id="password" placeholder="Password" required="">
                      <?php if($errors->has('password')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('password')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                    <div class="form-group">
                      <label for="confirm_password">Confirm Password</label>
                      <input type="password" class="form-control" name="password_confirmation" id="group" placeholder="Confirm Password" required="">
                    </div>
                    
                    <!-- <div class="form-group">
                      <div>
                        <p><a href="#">Click here</a> if you have an introduction code</p>
                      </div>
                    </div> -->

                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1" required="">
                      <label class="form-check-label" for="exampleCheck1">I agrre to <a href="#">terms of service</a> and <a href="#">Privacy policy</a></label>
                    </div>

                    <div class="button_holder">                      
                      <button type="submit" class="btn registration_btn">Next</button>
                      <div class="form-group">                      
                        <a href="#">Help for regitering #Likes is here</a>
                      </div>
                    </div>
                    
                </form>
              </div>
          </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>